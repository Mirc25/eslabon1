// Kotlin DSL without external imports
pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

// Read flutter.sdk from local.properties
val props = java.util.Properties()
val lp = file("local.properties")
if (lp.exists()) {
    java.io.FileInputStream(lp).use { fis -> props.load(fis) }
}
val flutterSdkPath = props.getProperty("flutter.sdk")
    ?: throw GradleException("Missing 'flutter.sdk' in local.properties (e.g. C:\\\\src\\\\flutter)")

// Expose the Flutter plugin from the SDK (we do NOT declare a version)
includeBuild("$flutterSdkPath/packages/flutter_tools/gradle")

plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
    id("com.google.gms.google-services") version "4.4.2" apply false
}

dependencyResolutionManagement {
    // Avoid conflicts with project repos and allow the Flutter plugin to add its own
    repositoriesMode.set(RepositoriesMode.PREFER_SETTINGS)
    repositories {
        google()
        mavenCentral()
        // Repo that Flutter uses for native binaries
        maven { url = uri("https://storage.googleapis.com/download.flutter.io") }
    }
}

include(":app")