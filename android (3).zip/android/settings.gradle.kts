// android/settings.gradle.kts
pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

val props = java.util.Properties()
val lp = file("local.properties")
if (lp.exists()) {
    java.io.FileInputStream(lp).use { props.load(it) }
}
val flutterSdkPath = props.getProperty("flutter.sdk")
require(!flutterSdkPath.isNullOrBlank()) {
    "Falta flutter.sdk en local.properties (ej: C:\\\\flutter)"
}

// 👇 CRÍTICO: enlaza Flutter Tools para que el embedding entre al classpath
includeBuild("$flutterSdkPath/packages/flutter_tools/gradle")

plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
    id("dev.flutter.flutter-gradle-plugin") version "1.0.0" apply false
    id("com.google.gms.google-services") version "4.4.2" apply false
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.PREFER_SETTINGS)
    repositories {
        google()
        mavenCentral()
        // Repos del embedding de Flutter
        maven { url = uri("https://storage.googleapis.com/download.flutter.io") }
    }
}

include(":app")
