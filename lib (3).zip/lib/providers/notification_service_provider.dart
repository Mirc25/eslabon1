import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:eslabon_flutter/router/app_router.dart'; // Importa el archivo del router
import 'package:eslabon_flutter/services/notification_service.dart';

// Este proveedor proporciona la instancia de GoRouter
final appRouterGoProvider = Provider<GoRouter>((ref) {
  return router;
});

// Este proveedor ahora depende del router para inicializar el servicio de notificaciones
final notificationServiceProvider = Provider<NotificationService>((ref) {
  final goRouter = ref.watch(appRouterGoProvider);
  return NotificationService(appRouter: goRouter);
});