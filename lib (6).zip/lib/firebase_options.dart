﻿import 'dart:io' show Platform;
import 'package:firebase_core/firebase_core.dart';

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (Platform.isAndroid) return android;
    throw UnsupportedError('Sólo Android configurado.');
  }

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyDwkbo70gthTE7Dqr2Fyf8q9Dj3HhcxCR0',
    appId: '1:548781604480:android:91fd1f50679905ea96f065',
    messagingSenderId: '548781604480',
    projectId: 'eslabon-app',
    storageBucket: 'eslabon-app.firebasestorage.app',
  );
}
