// lib/services/notification_service.dart
import 'package:go_router/go_router.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class NotificationService {
  final GoRouter _router;

  NotificationService({required GoRouter appRouter}) : _router = appRouter {
    _initFirebaseMessaging();
  }

  void _initFirebaseMessaging() {
    FirebaseMessaging.instance.getInitialMessage().then((message) {
      if (message != null) {
        _handleMessage(message);
      }
    });

    FirebaseMessaging.onMessage.listen((message) {
      _handleMessage(message);
    });

    FirebaseMessaging.onMessageOpenedApp.listen((message) {
      _handleMessage(message);
    });
  }

  void _handleMessage(RemoteMessage message) {
    print("Received message: ${message.notification?.title}");
    print("Message data: ${message.data}");

    if (message.data.isNotEmpty) {
      handleNotificationNavigation(message.data);
    }
  }

  void handleNotificationNavigation(Map<String, dynamic> notificationData) {
    final String? navigationPath = notificationData['navigationPath'];
    final Map<String, dynamic>? navigationExtra = notificationData['navigationExtra'] as Map<String, dynamic>?;
    final String? notificationId = notificationData['notificationId'];
    final String? notificationType = notificationData['type'];

    debugPrint('--- INICIO DEBUG NAVEGACIÓN ---');
    debugPrint('Datos de notificación recibidos:');
    debugPrint('  navigationPath: $navigationPath');
    debugPrint('  navigationExtra: $navigationExtra');
    debugPrint('  notificationId: $notificationId');
    debugPrint('  notificationType: $notificationType');
    debugPrint('  _router está disponible: ${_router != null}'); // Verifica si el router es nulo

    if (navigationPath != null && _router != null) {
      if (notificationId != null) {
        FirebaseFirestore.instance.collection('notifications').doc(notificationId).update({'read': true});
        debugPrint('  Notificación $notificationId marcada como leída.');
      }

      final Uri uri = Uri.parse(navigationPath);
      
      // ✅ Lógica específica para notificaciones de tipo 'offer_received'
      if (notificationType == 'offer_received') {
        final String? requestId = navigationExtra?['requestId']; // ✅ CORREGIDO: requestId y helperId vienen en navigationExtra
        final String? helperId = navigationExtra?['helperId'];

        debugPrint('  Tipo de notificación es "offer_received".');
        debugPrint('  Extrayendo requestId: $requestId, helperId: $helperId');

        if (requestId != null && helperId != null) {
          debugPrint('  Redirigiendo a calificar ayudador: $requestId / $helperId');
          _router.pushNamed(
            'rate-helper', // La ruta nombrada para RateHelperScreen
            pathParameters: {'requestId': requestId}, // requestId como pathParameter
            extra: {
              'helperId': helperId, // helperId como extra
              'helperName': navigationExtra?['helperName'], // Nombre del ayudador como extra
              'requestData': navigationExtra?['requestData'], // Datos de la solicitud como extra
            },
          );
        } else {
          debugPrint('  DEBUG NAVIGATION ERROR: Datos incompletos para notificación de oferta (requestId o helperId faltantes en navigationExtra).');
        }
      }
      // ✅ ACTUALIZADO: Lógica para navegar a RateRequesterScreen desde notificación
      else if (notificationType == 'helper_rated') { // Si el ayudador fue calificado, redirige a que califique al solicitante
        final String? requestId = navigationExtra?['requestId'];
        final String? requesterId = navigationExtra?['requesterId'];
        final String? requesterName = navigationExtra?['requesterName'];

        debugPrint('  Tipo de notificación es "helper_rated".');
        debugPrint('  Extrayendo requestId: $requestId, requesterId: $requesterId, requesterName: $requesterName');

        if (requestId != null && requesterId != null && requesterName != null) {
          debugPrint('  Redirigiendo a calificar solicitante: $requestId / $requesterId');
          _router.pushNamed(
            'rate-requester',
            pathParameters: {'requestId': requestId},
            extra: {
              'requesterId': requesterId,
              'requesterName': requesterName,
            },
          );
        } else {
          debugPrint('  DEBUG NAVIGATION ERROR: Datos incompletos para notificación de calificación de ayudador (requestId, requesterId o requesterName faltantes en navigationExtra).');
        }
      }
      // Lógica para otras rutas (chat, etc.)
      else if (navigationPath.startsWith('/chat/')) {
        final String chatPartnerId = uri.pathSegments.last;
        debugPrint('  Ruta es /chat/. Extrayendo chatPartnerId: $chatPartnerId');
        _router.pushNamed(
          'chat_screen',
          pathParameters: {'chatPartnerId': chatPartnerId},
          extra: navigationExtra,
        );
      }
      else {
        debugPrint('  Ruta no reconocida o no necesita pathParameters. Usando push().');
        _router.push(navigationPath, extra: navigationExtra);
      }
    } else {
      print('  DEBUG NAVIGATION: No hay ruta de navegación en los datos de la notificación o _router es nulo.');
    }
    debugPrint('--- FIN DEBUG NAVEGACIÓN ---');
  }
}
