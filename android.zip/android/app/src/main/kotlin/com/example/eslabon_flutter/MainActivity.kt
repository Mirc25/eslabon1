package com.example.eslabon_flutter  // ← CAMBIALO si tu paquete es diferente

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity() {
}
