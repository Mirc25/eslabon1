// lib/services/notification_service.dart
import 'package:go_router/go_router.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class NotificationService {
  final GoRouter _router; // ✅ CORREGIDO: Ahora es final y se inicializa en el constructor

  // ✅ CORREGIDO: El constructor ahora requiere una instancia de GoRouter
  NotificationService({required GoRouter appRouter}) : _router = appRouter {
    _initFirebaseMessaging();
  }

  // ✅ ELIMINADO: setRouter ya no es necesario
  // void setRouter(GoRouter router) {
  //   _router = router;
  // }

  void _initFirebaseMessaging() {
    FirebaseMessaging.instance.getInitialMessage().then((message) {
      if (message != null) {
        _handleMessage(message);
      }
    });

    FirebaseMessaging.onMessage.listen((message) {
      _handleMessage(message);
    });

    FirebaseMessaging.onMessageOpenedApp.listen((message) {
      _handleMessage(message);
    });
  }

  void _handleMessage(RemoteMessage message) {
    print("Received message: ${message.notification?.title}");
    print("Message data: ${message.data}");

    if (message.data.isNotEmpty) {
      handleNotificationNavigation(message.data);
    }
  }

  void handleNotificationNavigation(Map<String, dynamic> notificationData) {
    final String? navigationPath = notificationData['navigationPath'];
    final Map<String, dynamic>? navigationExtra = notificationData['navigationExtra'] as Map<String, dynamic>?;
    final String? notificationId = notificationData['notificationId'];

    if (navigationPath != null) { // ✅ _router ya no puede ser nulo aquí
      if (notificationId != null) {
        FirebaseFirestore.instance.collection('notifications').doc(notificationId).update({'read': true});
      }

      final Uri uri = Uri.parse(navigationPath);
      
      // Manejo específico para la ruta de calificación de ayudador
      if (navigationPath.startsWith('/rate-helper/')) {
        final String requestId = uri.pathSegments.last;
        _router.pushNamed(
          'rate-helper',
          pathParameters: {'requestId': requestId},
          extra: navigationExtra,
        );
        print('DEBUG NAVIGATION: Navegando a ruta nombrada: rate-helper con requestId: $requestId y extra: $navigationExtra');
      }
      // Manejo específico para la ruta de chat
      else if (navigationPath.startsWith('/chat/')) {
        final String chatPartnerId = uri.pathSegments.last;
        _router.pushNamed(
          'chat_screen',
          pathParameters: {'chatPartnerId': chatPartnerId},
          extra: navigationExtra,
        );
        print('DEBUG NAVIGATION: Navegando a chat_screen con chatPartnerId: $chatPartnerId y extra: $navigationExtra');
      }
      // Manejo específico para la ruta de calificación de solicitante
      else if (navigationPath.startsWith('/rate-requester/')) {
        final String requestId = uri.pathSegments.last;
        _router.pushNamed(
          'rate-requester',
          pathParameters: {'requestId': requestId},
          extra: navigationExtra,
        );
        print('DEBUG NAVIGATION: Navegando a ruta nombrada: rate-requester con requestId: $requestId y extra: $navigationExtra');
      }
      else {
        // Para otras rutas que no son nombradas o no tienen pathParameters complejos
        _router.push(navigationPath, extra: navigationExtra);
        print('DEBUG NAVIGATION: Navegando a: $navigationPath con extra: $navigationExtra');
      }
    } else {
      print('DEBUG NAVIGATION: No hay ruta de navegación en los datos de la notificación.');
    }
  }
}
