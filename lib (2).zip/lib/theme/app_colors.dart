﻿import 'package:flutter/material.dart';

class AppColors {
  static const Color primary = Colors.blue;
  static const Color accent = Colors.amber;
  static const Color scaffoldBackground = Colors.black;
}

