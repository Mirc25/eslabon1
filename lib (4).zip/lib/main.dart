// lib/main.dart
import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart' show kDebugMode;
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_app_check/firebase_app_check.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'firebase_options.dart';
import 'router/app_router.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await EasyLocalization.ensureInitialized();

  // Si tenés firebase_options.dart generado por FlutterFire CLI:
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);

  // ***** APP CHECK *****
  // En debug: usa AndroidProvider.debug (agregá el token en Firebase Console > App Check).
  // En release: usa Play Integrity (asegurá SHA-256 en Firebase y subir a Play).
  await FirebaseAppCheck.instance.activate(
    androidProvider: kDebugMode
        ? AndroidProvider.debug
        : AndroidProvider.playIntegrity,
    // Si algún día compilas iOS:
    // appleProvider: AppleProvider.appAttestWithDeviceCheckFallback,
    // Para Web (si aplica) necesitás site key de reCAPTCHA Enterprise:
    // webProvider: ReCaptchaEnterpriseProvider('TU_SITE_KEY'),
  );

  runApp(
    ProviderScope(
      child: EasyLocalization(
        supportedLocales: const [Locale('es'), Locale('en')],
        path: 'assets/translations',
        fallbackLocale: const Locale('es'),
        child: const MyApp(),
      ),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp.router(
      debugShowCheckedModeBanner: false,
      title: 'Eslabón',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF2E7D32)),
        useMaterial3: true,
      ),
      // Easy Localization -> pasamos delegates/locale/soportedLocales al MaterialApp
      localizationsDelegates: context.localizationDelegates,
      supportedLocales: context.supportedLocales,
      locale: context.locale,

      routerConfig: AppRouter.router,
    );
  }
}

/// Pantalla mínima opcional — sólo si querés validar arranque sin router.
// class PlaceholderHome extends StatelessWidget {
//   const PlaceholderHome({super.key});
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(title: const Text('Eslabón — Init OK')),
//       body: const Center(
//         child: Padding(
//           padding: EdgeInsets.all(16),
//           child: Text(
//             'Firebase inicializado y App Check activo.\n'
//             'Si registraste el Debug Token en App Check, los 403 desaparecen.',
//             textAlign: TextAlign.center,
//           ),
//         ),
//       ),
//     );
//   }
// }
