// lib/services/notification_service.dart
import 'package:go_router/go_router.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'dart:convert'; // ✅ AÑADIDO: Import para jsonDecode

class NotificationService {
  final GoRouter _router;

  NotificationService({required GoRouter appRouter}) : _router = appRouter {
    _initFirebaseMessaging();
  }

  void _initFirebaseMessaging() {
    FirebaseMessaging.instance.getInitialMessage().then((message) {
      if (message != null) {
        _handleMessage(message);
      }
    });

    FirebaseMessaging.onMessage.listen((message) {
      _handleMessage(message);
    });

    FirebaseMessaging.onMessageOpenedApp.listen((message) {
      _handleMessage(message);
    });
  }

  void _handleMessage(RemoteMessage message) {
    print("Received message: ${message.notification?.title}");
    print("Message data: ${message.data}");

    if (message.data.isNotEmpty) {
      // ✅ Detectar si los datos están anidados en 'data'
final Map<String, dynamic> payload = message.data['data'] != null
    ? Map<String, dynamic>.from(message.data['data'])
    : message.data;

handleNotificationNavigation(payload);
    }
  }

  void handleNotificationNavigation(Map<String, dynamic> notificationData) {
    // ✅ CORREGIDO: Extraer y decodificar requestData
    final String? notificationType = notificationData['type'];
    final String? notificationId = notificationData['notificationId']; // Para marcar como leída
    final String? requestId = notificationData['requestId']; // Extraer directamente
    final String? helperId = notificationData['helperId']; // Extraer directamente
    final String? helperName = notificationData['helperName']; // Extraer directamente
    final String? requesterId = notificationData['requesterId']; // Extraer directamente (para helper_rated)
    final String? requesterName = notificationData['requesterName']; // Extraer directamente (para helper_rated)
    final String? ratingString = notificationData['rating']; // Viene como string (para helper_rated)
    final double? rating = ratingString != null ? double.tryParse(ratingString) : null;

    Map<String, dynamic> decodedRequestData = {}; // ✅ Variable para el mapa decodificado
    if (notificationData['requestData'] != null && notificationData['requestData']!.isNotEmpty) {
      try {
        decodedRequestData = jsonDecode(notificationData['requestData']!) as Map<String, dynamic>;
      } catch (e) {
        print('Error al decodificar requestData: $e');
      }
    }

    debugPrint('--- INICIO DEBUG NAVEGACIÓN ---');
    debugPrint('Datos de notificación recibidos:');
    debugPrint('  notificationType: $notificationType');
    debugPrint('  notificationId: $notificationId');
    debugPrint('  requestId: $requestId');
    debugPrint('  helperId: $helperId');
    debugPrint('  helperName: $helperName');
    debugPrint('  requesterId: $requesterId');
    debugPrint('  requesterName: $requesterName');
    debugPrint('  rating: $rating');
    debugPrint('  decodedRequestData: $decodedRequestData'); // ✅ DEBUG: Mostrar requestData decodificado
    debugPrint('  _router está disponible: ${_router != null}');

    if (_router == null) {
      debugPrint('  DEBUG NAVIGATION ERROR: GoRouter no está disponible.');
      return;
    }

    // ✅ CORREGIDO: No marcar la notificación como leída aquí, ya que no tenemos userId para la ruta completa.
    // La lógica para marcar como leída debe estar en NotificationsScreen o donde userId esté disponible.
    // if (notificationId != null) {
    //   FirebaseFirestore.instance.collection('notifications').doc(notificationId).update({'read': true});
    //   debugPrint('  Notificación $notificationId marcada como leída.');
    // }

    switch (notificationType) {
      case 'offer_received':
        if (requestId != null && helperId != null && helperName != null) { // ✅ Validar helperName también
          debugPrint('  Redirigiendo a calificar ayudador: $requestId / $helperId');
          _router.pushNamed(
            'rate-helper', // La ruta nombrada para RateHelperScreen
            pathParameters: {'requestId': requestId}, // requestId como pathParameter
            extra: {
              'helperId': helperId,
              'helperName': helperName,
              'requestData': decodedRequestData, // ✅ PASADO: requestData decodificado
            },
          );
        } else {
          debugPrint('  DEBUG NAVIGATION ERROR: Datos incompletos para "offer_received" (requestId, helperId o helperName faltantes).');
        }
        break;
      case 'helper_rated': // Cuando el ayudador es calificado por el solicitante
        if (requestId != null && requesterId != null && requesterName != null) {
          debugPrint('  Redirigiendo a calificar solicitante: $requestId / $requesterId');
          _router.pushNamed(
            'rate-requester',
            pathParameters: {'requestId': requestId},
            extra: {
              'requesterId': requesterId,
              'requesterName': requesterName,
              'requestId': requestId, // Asegurarse de pasar el requestId
            },
          );
        } else {
          debugPrint('  DEBUG NAVIGATION ERROR: Datos incompletos para "helper_rated" (requestId, requesterId o requesterName faltantes).');
        }
        break;
      case 'new_request':
        if (requestId != null) {
          debugPrint('  Redirigiendo a detalles de nueva solicitud: $requestId');
          _router.pushNamed(
            'request_detail',
            pathParameters: {'requestId': requestId},
            extra: decodedRequestData, // ✅ PASADO: requestData decodificado
          );
        } else {
          debugPrint('  DEBUG NAVIGATION ERROR: ID de solicitud faltante para "new_request".');
        }
        break;
      case 'chat_message':
        final String? chatPartnerId = notificationData['chatPartnerId'];
        final String? chatPartnerName = notificationData['chatPartnerName'];
        if (chatPartnerId != null && chatPartnerName != null) {
          debugPrint('  Redirigiendo a chat con: $chatPartnerName ($chatPartnerId)');
          _router.go(
            '/chat/$chatPartnerId',
            extra: {'chatPartnerName': chatPartnerName},
          );
        } else {
          debugPrint('  DEBUG NAVIGATION ERROR: Datos de chat incompletos.');
        }
        break;
      default:
        debugPrint('  Tipo de notificación desconocido o sin lógica de navegación específica: $notificationType');
        _router.go('/main');
        break;
    }
    debugPrint('--- FIN DEBUG NAVEGACIÓN ---');
  }
}
