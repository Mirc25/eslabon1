// lib/services/app_services.dart
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:url_launcher/url_launcher.dart';

class AppServices {
  final FirebaseFirestore _firestore;
  final FirebaseAuth _auth;

  AppServices(this._firestore, this._auth);

  static void showSnackBar(BuildContext context, String message, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: color,
        duration: const Duration(seconds: 3),
      ),
    );
  }

  Future<void> addComment(BuildContext context, String requestId, String commentText) async {
    final User? currentUser = _auth.currentUser;

    if (currentUser == null) {
      AppServices.showSnackBar(context, 'Debes iniciar sesión para comentar.', Colors.red);
      return;
    }

    String userName = currentUser.displayName ?? 'Usuario Anónimo';
    String? userAvatar = currentUser.photoURL;

    if (currentUser.displayName == null || currentUser.displayName!.isEmpty || currentUser.photoURL == null) {
      try {
        final userDoc = await _firestore.collection('users').doc(currentUser.uid).get();
        if (userDoc.exists && userDoc.data() != null) {
          userName = userDoc.data()!['name'] ?? userName;
          userAvatar = userDoc.data()!['profilePicture'] ?? userAvatar;
        }
      } catch (e) {
        print('Error fetching user name/avatar for comment: $e');
      }
    }

    try {
      await _firestore
          .collection('solicitudes-de-ayuda')
          .doc(requestId)
          .collection('comments')
          .add({
        'userId': currentUser.uid,
        'userName': userName,
        'userAvatar': userAvatar,
        'text': commentText,
        'timestamp': FieldValue.serverTimestamp(),
      });
    } catch (e) {
      print('Error adding comment: $e');
      AppServices.showSnackBar(context, 'Error al enviar comentario: $e', Colors.red);
    }
  }

  Future<void> createOfferAndNotifyRequester({
    required BuildContext context,
    required String requestId,
    required String requesterId,
    required String helperId,
    required String helperName,
    String? helperAvatarUrl,
    required String requestTitle,
    required Map<String, dynamic> requestData,
  }) async {
    try {
      await _firestore
          .collection('solicitudes-de-ayuda')
          .doc(requestId)
          .collection('offers')
          .add({
        'helperId': helperId,
        'requesterId': requesterId,
        'timestamp': FieldValue.serverTimestamp(),
        'status': 'pending',
        'helperName': helperName,
        'helperAvatarUrl': helperAvatarUrl,
        'requestId': requestId,
      });

      await _firestore.collection('solicitudes-de-ayuda').doc(requestId).update({
        'offersCount': FieldValue.increment(1),
      });
      
      final notificationData = {
          'notificationType': 'offer_received',
          'navigationPath': '/rate-helper/$requestId',
          'requestId': requestId,
          'helperId': helperId,
          'helperName': helperName,
          'requestData': requestData,
      };
      
      debugPrint("📦 Notificación enviada: $notificationData");

      await addNotification(
        recipientId: requesterId,
        type: 'offer_received',
        title: '¡Nueva oferta de ayuda!',
        body: '$helperName ha ofrecido ayuda para tu solicitud: "$requestTitle". ¡Por favor, coordina con él!',
        data: notificationData,
      );

      print('Oferta creada y notificación enviada con éxito.');

    } catch (e) {
      print('Error al crear oferta y notificar: $e');
      AppServices.showSnackBar(context, 'Error al ofrecer ayuda.', Colors.red);
      rethrow;
    }
  }

  Future<void> addNotification({
    required String recipientId,
    required String type,
    required String title,
    required String body,
    Map<String, dynamic>? data,
  }) async {
    try {
      // ✅ Esta es la corrección crucial: Guardar en la subcolección 'notifications' del usuario.
      await _firestore.collection('users').doc(recipientId).collection('notifications').add({
        'type': type,
        'title': title,
        'body': body,
        'timestamp': FieldValue.serverTimestamp(),
        'read': false,
        'data': data ?? {},
      });
    } catch (e) {
      print('Error al añadir notificación: $e');
    }
  }

  Future<void> notifyHelperAfterRequesterRates({
    required BuildContext context,
    required String helperId,
    required String requesterId,
    required String requesterName,
    required double rating,
    required String requestId,
    required String requestTitle,
  }) async {
    try {
      await addNotification(
        recipientId: helperId,
        type: 'helper_rated',
        title: '¡Has sido calificado!',
        body: '$requesterName te ha calificado con ${rating.toStringAsFixed(1)} estrellas por tu ayuda en "$requestTitle".',
        data: {
          'notificationType': 'helper_rated',
          'navigationPath': '/rate-requester/$requestId',
          'requestId': requestId,
          'requesterId': requesterId,
          'requesterName': requesterName,
          'rating': rating,
        },
      );
      print('Notificación de calificación enviada al ayudador.');
    } catch (e) {
      print('Error al notificar al ayudador sobre la calificación: $e');
      AppServices.showSnackBar(context, 'Error al enviar notificación de calificación.', Colors.red);
    }
  }

  Future<void> launchMap(BuildContext context, double latitude, double longitude) async {
    final String googleMapsUrl = 'https://maps.google.com/?q=$latitude,$longitude';
    final Uri uri = Uri.parse(googleMapsUrl);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri);
    } else {
      AppServices.showSnackBar(context, 'No se pudo abrir Google Maps.', Colors.red);
    }
  }

  Future<void> launchWhatsapp(BuildContext context, String phoneNumber) async {
    String whatsappUrl = "whatsapp://send?phone=$phoneNumber";
    if (await canLaunchUrl(Uri.parse(whatsappUrl))) {
      await launchUrl(Uri.parse(whatsappUrl));
    } else {
      AppServices.showSnackBar(context, 'No se pudo abrir WhatsApp. Asegúrate de tener la aplicación instalada.', Colors.red);
    }
  }
}