import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:intl/intl.dart'; 

import 'package:eslabon_flutter/services/app_services.dart';
import 'package:eslabon_flutter/user_reputation_widget.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:eslabon_flutter/utils/firestore_utils.dart';

class RequestDetailScreen extends ConsumerStatefulWidget {
  final String requestId;
  final Map<String, dynamic>? requestData; // ✅ AÑADIDO: Ahora acepta requestData como opcional

  const RequestDetailScreen({
    super.key,
    required this.requestId,
    this.requestData, // ✅ AÑADIDO: Parámetro para recibir los datos
  });

  @override
  ConsumerState<RequestDetailScreen> createState() => _RequestDetailScreenState();
}

class _RequestDetailScreenState extends ConsumerState<RequestDetailScreen> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;
  late final AppServices _appServices;

  final Map<String, TextEditingController> _commentControllers = {};
  
  double _userRatingForThisRequest = 0.0;
  TextEditingController _ratingCommentController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _appServices = AppServices(_firestore, _auth);
    // Si requestData no viene, lo cargamos desde Firestore.
    // Si viene, lo usamos directamente para evitar una carga inicial.
    // La StreamBuilder de más abajo seguirá escuchando cambios en tiempo real.
  }

  @override
  void dispose() {
    _commentControllers.forEach((key, controller) => controller.dispose());
    _ratingCommentController.dispose();
    super.dispose();
  }

  void _showSnackBar(String message, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: color,
        duration: const Duration(seconds: 3),
      ),
    );
  }

  Future<void> _addComment(String requestId, String commentText) async {
    final User? currentUser = _auth.currentUser;
    if (currentUser == null || commentText.trim().isEmpty) {
      _showSnackBar('Debes iniciar sesión para comentar y el comentario no puede estar vacío.', Colors.red);
      return;
    }

    try {
      await _appServices.addComment(context, requestId, commentText);
      _showSnackBar('Comentario enviado.', Colors.green);
    } on FirebaseException catch (e) {
      print("Error adding comment: $e");
      _showSnackBar('Error de Firebase al enviar comentario: ${e.message}', Colors.red);
    } catch (e) {
      print("Unexpected error adding comment: $e");
      _showSnackBar('Ocurrió un error inesperado al enviar el comentario.', Colors.red);
    } finally {
      _commentControllers[requestId]?.clear();
    }
  }

  // ✅ CORREGIDO: showCommentsModal ahora usa context.pop() correctamente.
  void _showCommentsModal(String requestId) {
    if (!_commentControllers.containsKey(requestId)) {
      _commentControllers[requestId] = TextEditingController();
    }
    final TextEditingController commentController = _commentControllers[requestId]!;
    final User? currentUser = _auth.currentUser;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.grey[900],
      builder: (modalContext) {
        return Padding(
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(modalContext).viewInsets.bottom,
          ),
          child: Container(
            height: MediaQuery.of(modalContext).size.height * 0.75,
            color: Colors.grey[900],
            child: Column(
              children: [
                AppBar(
                  backgroundColor: Colors.grey[850],
                  title: const Text('Comentarios', style: TextStyle(color: Colors.white)),
                  leading: IconButton(
                    icon: const Icon(Icons.close, color: Colors.white),
                    onPressed: () => Navigator.pop(modalContext),
                  ),
                ),
                Expanded(
                  child: StreamBuilder<QuerySnapshot>(
                    stream: _firestore
                        .collection('solicitudes-de-ayuda')
                        .doc(requestId)
                        .collection('comments')
                        .orderBy('timestamp', descending: true)
                        .snapshots(),
                    builder: (context, commentSnapshot) {
                      if (commentSnapshot.hasError) {
                        return Center(child: Text('Error: ${commentSnapshot.error}', style: const TextStyle(color: Colors.red)));
                      }
                      if (commentSnapshot.connectionState == ConnectionState.waiting) {
                        return const Center(child: CircularProgressIndicator(color: Colors.amber));
                      }

                      final List<Map<String, dynamic>> comments = commentSnapshot.data!.docs
                          .map((doc) => doc.data() as Map<String, dynamic>)
                          .toList();

                      if (comments.isEmpty) {
                        return const Center(
                          child: Text(
                            'Sé el primero en comentar.',
                            style: TextStyle(color: Colors.white54, fontSize: 16),
                            textAlign: TextAlign.center,
                          ),
                        );
                      }

                      return ListView.builder(
                        itemCount: comments.length,
                        reverse: true, // ✅ CORREGIDO: Para mostrar los comentarios más recientes abajo
                        itemBuilder: (context, index) {
                          final comment = comments[index];
                          final String commentUser = comment['userName'] ?? 'Usuario';
                          final String commentText = comment['text'] ?? 'Sin comentario';
                          final String? userAvatar = comment['userAvatar'] as String?;
                          final Timestamp? commentTimestamp = comment['timestamp'] as Timestamp?;

                          String formattedTime = '';
                          if (commentTimestamp != null) {
                            final DateTime date = commentTimestamp.toDate();
                            formattedTime = DateFormat('dd/MM HH:mm').format(date);
                          }

                          return Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                CircleAvatar(
                                  radius: 18,
                                  backgroundImage: (userAvatar != null && userAvatar.startsWith('http'))
                                      ? NetworkImage(userAvatar)
                                      : const AssetImage('assets/default_avatar.png') as ImageProvider,
                                  backgroundColor: Colors.grey[700],
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          Expanded(
                                            child: Text(
                                              commentUser,
                                              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14, color: Colors.white),
                                              maxLines: 1,
                                              overflow: TextOverflow.ellipsis,
                                            ),
                                          ),
                                          Text(
                                            formattedTime,
                                            style: TextStyle(fontSize: 10, color: Colors.white54),
                                          ),
                                        ],
                                      ),
                                      Text(
                                        commentText,
                                        style: const TextStyle(fontSize: 13, color: Colors.white70),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          );
                        },
                      );
                    },
                  ),
                ),
                if (currentUser != null)
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Row(
                      children: [
                        Expanded(
                          child: TextField(
                            controller: commentController,
                            style: const TextStyle(color: Colors.white, fontSize: 14),
                            decoration: InputDecoration(
                              hintText: 'Escribe un comentario...',
                              hintStyle: TextStyle(color: Colors.white54, fontSize: 14),
                              filled: true,
                              fillColor: Colors.grey[800],
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(25),
                                borderSide: BorderSide.none,
                              ),
                              contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                            ),
                            minLines: 1,
                            maxLines: 5,
                          ),
                        ),
                        const SizedBox(width: 8),
                        FloatingActionButton(
                          mini: true,
                          backgroundColor: Colors.amber,
                          onPressed: () async {
                            if (commentController.text.trim().isNotEmpty) {
                              await _addComment(requestId, commentController.text);
                              commentController.clear();
                            }
                          },
                          child: const Icon(Icons.send, color: Colors.black),
                        ),
                      ],
                    ),
                  ),
                if (currentUser == null)
                  const Padding(
                    padding: EdgeInsets.all(16.0),
                    child: Text(
                      'Inicia sesión para comentar en esta publicación.',
                      style: TextStyle(color: Colors.white54, fontSize: 14),
                      textAlign: TextAlign.center,
                    ),
                  ),
              ],
            ),
          ),
        );
      },
    );
  }

  void _showImageFullScreen(BuildContext context, String imageUrl) {
    showDialog(
      context: context,
      builder: (BuildContext dialogContext) {
        return Dialog(
          backgroundColor: Colors.black,
          insetPadding: EdgeInsets.zero,
          child: GestureDetector(
            onTap: () => Navigator.pop(dialogContext),
            child: InteractiveViewer(
              child: SizedBox(
                width: MediaQuery.of(dialogContext).size.width,
                height: MediaQuery.of(dialogContext).size.height,
                child: Image.network(
                  imageUrl,
                  fit: BoxFit.contain,
                  errorBuilder: (context, error, stackTrace) => Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(Icons.broken_image, color: Colors.white54, size: 100),
                        const SizedBox(height: 10),
                        Text('Error al cargar imagen', style: TextStyle(color: Colors.white54)),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildCommentsButton(String requestId) {
    return StreamBuilder<QuerySnapshot>(
      stream: _firestore
          .collection('solicitudes-de-ayuda')
          .doc(requestId)
          .collection('comments')
          .snapshots(),
      builder: (context, commentSnapshot) {
        if (commentSnapshot.hasError) {
          return const Row(children: [Icon(Icons.comment, color: Colors.red, size: 18), SizedBox(width: 4), Text('Error', style: TextStyle(fontSize: 10, color: Colors.red))]);
        }
        if (commentSnapshot.connectionState == ConnectionState.waiting) {
          return const Row(children: [Icon(Icons.comment, color: Colors.grey, size: 18), SizedBox(width: 4), Text('...', style: TextStyle(fontSize: 10, color: Colors.grey))]);
        }

        final int commentsCount = commentSnapshot.data!.docs.length;

        return GestureDetector(
          onTap: () => _showCommentsModal(requestId),
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 2.0),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.comment, color: Colors.white, size: 18),
                const SizedBox(width: 4),
                Text(
                  commentsCount.toString(),
                  style: const TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: Colors.white),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final User? currentUser = _auth.currentUser;

    return Scaffold(
      backgroundColor: Colors.black, 
      appBar: AppBar(
        title: const Text('Detalles de la Solicitud', style: TextStyle(color: Colors.white)),
        backgroundColor: Colors.grey[900], 
        iconTheme: const IconThemeData(color: Colors.white), 
      ),
      // ✅ CORREGIDO: Usar widget.requestData si está disponible, de lo contrario, usar StreamBuilder.
      // Esto evita una carga inicial si los datos ya fueron pasados.
      body: widget.requestData != null 
          ? _buildBodyWithData(context, widget.requestData!)
          : StreamBuilder<DocumentSnapshot>(
              stream: _firestore.collection('solicitudes-de-ayuda').doc(widget.requestId).snapshots(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator(color: Colors.amber));
                }

                if (snapshot.hasError) {
                  return Center(child: Text('Error al cargar la solicitud: ${snapshot.error}', style: const TextStyle(color: Colors.red)));
                }

                if (!snapshot.hasData || !snapshot.data!.exists) {
                  return const Center(child: Text('Solicitud no encontrada.', style: TextStyle(color: Colors.white)));
                }

                final requestData = snapshot.data!.data() as Map<String, dynamic>;
                return _buildBodyWithData(context, requestData);
              },
            ),
    );
  }

  // ✅ AÑADIDO: Nuevo método para construir el cuerpo de la pantalla con los datos de la solicitud
  Widget _buildBodyWithData(BuildContext context, Map<String, dynamic> requestData) {
    final User? currentUser = _auth.currentUser;

    final String requesterUserId = requestData['userId'] as String? ?? '';
    final String requesterName = requestData['nombre'] as String? ?? 'Usuario Anónimo';
    final String requesterPhone = requestData['phone'] as String? ?? 'N/A'; 
    final String requesterEmail = requestData['email'] as String? ?? 'N/A';
    final String requesterAddress = requestData['address'] as String? ?? 'No especificada'; // Usar 'address' que es la completa
    final String requesterDOB = requestData['fecha_nacimiento'] as String? ?? 'No especificada'; 

    final bool showWhatsapp = requestData['showWhatsapp'] as bool? ?? false;
    final bool showEmail = requestData['showEmail'] as bool? ?? false; // Usar 'showEmail' flag
    
    final String memberSince = requestData['memberSince'] as String? ?? 'N/A';
    final int helpedCount = requestData['helpedCount'] as int? ?? 0;
    final int receivedHelpCount = requestData['receivedHelpCount'] as int? ?? 0;

    final dynamic timestampData = requestData['timestamp'];
    final Timestamp timestamp = timestampData is Timestamp ? timestampData : Timestamp.now();

    final DateTime requestTime = timestamp.toDate();
    final DateTime now = DateTime.now();
    final Duration remainingTime = requestTime.add(const Duration(hours: 24)).difference(now);

    String timeRemainingText;
    if (remainingTime.isNegative) {
      timeRemainingText = 'Expirada';
    } else {
      final hours = remainingTime.inHours;
      final minutes = remainingTime.inMinutes.remainder(60);
      timeRemainingText = '$hours h $minutes min';
    }

    Color priorityColor = Colors.grey;
    switch (requestData['prioridad'] as String?) {
      case 'alta':
        priorityColor = Colors.redAccent;
        break;
      case 'media':
        priorityColor = Colors.orange;
        break;
      case 'baja':
        priorityColor = Colors.green;
        break;
      default:
        priorityColor = Colors.grey;
        break;
    }

    List<String> imageUrls = [];
    dynamic rawImages = requestData['imagenes'];
    if (rawImages != null) {
      if (rawImages is List) {
        imageUrls = List<String>.from(rawImages.where((item) => item is String));
      } else if (rawImages is String && rawImages.isNotEmpty) {
        imageUrls = [rawImages];
      }
    }
    String imageUrlToDisplay = imageUrls.isNotEmpty ? imageUrls.first : '';
    
    final double? latitude = requestData['latitude'] as double?;
    final double? longitude = requestData['longitude'] as double?;


    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Sección de Información del Solicitante
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded( 
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        CircleAvatar(
                          radius: 25,
                          backgroundImage: (requestData['avatar'] as String?) != null && (requestData['avatar'] as String).startsWith('http')
                              ? NetworkImage(requestData['avatar'] as String)
                              : const AssetImage('assets/default_avatar.png') as ImageProvider,
                          backgroundColor: Colors.grey[700],
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                requesterName, 
                                style: const TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.white),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                              UserReputationWidget(
                                userId: requesterUserId,
                                fromRequesters: false,
                              ),
                              Text(
                                requestData['localidad'] as String? ?? 'Desconocida', 
                                style: TextStyle(color: Colors.white70, fontSize: 12),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                              Text(
                                'Categoría: ${requestData['categoria'] as String? ?? 'N/A'}', 
                                style: TextStyle(
                                    color: Colors.cyanAccent, fontSize: 12, fontWeight: FontWeight.w600),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    // ✅ AÑADIDO: Info de contacto solo si showAddress es true, o si es el propio usuario o si siempre se muestra.
                    // Asumo que solo quieres mostrar estos detalles si el flag `showAddress` es true.
                    // Si showAddress es true, se muestran:
                    // Teléfono, Email, Dirección Completa, Fecha Nacimiento.
                    if (requestData['showAddress'] == true || currentUser?.uid == requesterUserId) ...[
                      Text('Teléfono: $requesterPhone', style: const TextStyle(color: Colors.white70, fontSize: 13)),
                      Text('Email: $requesterEmail', style: const TextStyle(color: Colors.white70, fontSize: 13)),
                      Text('Dirección: $requesterAddress', style: const TextStyle(color: Colors.white70, fontSize: 13)),
                      Text('Fecha Nacimiento: $requesterDOB', style: const TextStyle(color: Colors.white70, fontSize: 13)),
                    ],
                    const SizedBox(height: 8),
                    if (currentUser?.uid != requesterUserId)
                      ElevatedButton(
                        onPressed: () {
                          final User? currentUser = _auth.currentUser;
                          if (currentUser == null) {
                            _showSnackBar('Debes iniciar sesión para ofrecer ayuda.', Colors.red);
                            return;
                          }
                          // Lógica para ofrecer ayuda. Podría navegar a una pantalla de oferta o enviar a Firestore.
                          _showSnackBar('Has ofrecido ayuda a ${requesterName}!', Colors.green);
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.amber,
                          foregroundColor: Colors.black,
                          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                        ),
                        child: const Text('Ofrecer Ayuda', style: TextStyle(fontSize: 14)),
                      ),
                  ],
                ),
              ),
              Column( 
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: priorityColor,
                      borderRadius: BorderRadius.circular(5),
                    ),
                    child: Text(
                          'Prioridad ${requestData['prioridad'] as String? ?? 'N/A'}',
                      style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Expira en $timeRemainingText',
                    style: TextStyle(
                        color: remainingTime.isNegative ? Colors.red : Colors.lightGreenAccent,
                        fontSize: 12),
                  ),
                ],
              ),
            ],
          ),
          const Divider(height: 24, thickness: 1, color: Colors.grey),
          
          // Imagen y Descripción/Detalles
          if (imageUrls.isNotEmpty) // Mostrar solo si hay imágenes
            GestureDetector(
              onTap: () => _showImageFullScreen(context, imageUrlToDisplay),
              child: Center(
                child: Container(
                  height: 200,
                  width: double.infinity,
                  margin: const EdgeInsets.only(bottom: 16),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12),
                    image: DecorationImage(
                      image: NetworkImage(imageUrlToDisplay),
                      fit: BoxFit.cover,
                    ),
                  ),
                  child: Align(
                    alignment: Alignment.bottomRight,
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: CircleAvatar(
                        backgroundColor: Colors.black54,
                        child: Text(
                          '${imageUrls.length}',
                          style: const TextStyle(color: Colors.white),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),

          Text(
            'Descripción: ${requestData['descripcion'] as String? ?? 'Sin descripción'}',
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white),
          ),
          const SizedBox(height: 8),
          Text(
            requestData['detalle'] as String? ?? 'Sin detalles adicionales.',
            style: const TextStyle(fontSize: 14, color: Colors.white70),
          ),
          const SizedBox(height: 24),

          // Seccion de Contacto y Comentarios
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    if (latitude != null && longitude != null)
                      IconButton(
                        icon: const Icon(Icons.location_on, color: Colors.blue, size: 28),
                        onPressed: () => _appServices.launchMap(context, latitude, longitude),
                        tooltip: 'Ver mapa',
                      ),
                    if (showWhatsapp && requesterPhone.isNotEmpty) 
                      IconButton(
                        icon: const Icon(FontAwesomeIcons.whatsapp, color: Colors.green, size: 28),
                        onPressed: () => _appServices.launchWhatsapp(context, requesterPhone),
                        tooltip: 'WhatsApp',
                      ),
                    if (showEmail && requesterEmail.isNotEmpty) 
                      IconButton(
                        icon: const Icon(Icons.email, color: Colors.blueAccent, size: 28),
                        onPressed: () async {
                          final Uri emailLaunchUri = Uri(
                            scheme: 'mailto',
                            path: requesterEmail,
                            queryParameters: {'subject': 'Ayuda en Eslabón'},
                          );
                          if (await canLaunchUrl(emailLaunchUri)) {
                            await launchUrl(emailLaunchUri);
                          } else {
                            _showSnackBar('No se pudo abrir el correo.', Colors.red);
                          }
                        },
                        tooltip: 'Email',
                      ),
                  ],
                ),
              ),
              _buildCommentsButton(widget.requestId),
            ],
          ),
          const SizedBox(height: 24),

          // Información adicional del usuario (reputación, miembro desde, etc.)
          Text(
            'Miembro desde: ${memberSince}', // ✅ Considera cargar esto del perfil del usuario en Firestore
            style: const TextStyle(color: Colors.white54, fontSize: 12),
          ),
          Text(
            'Ayudó a ${helpedCount.toString().padLeft(4, '0')} Personas', // ✅ Considera cargar esto del perfil del usuario
            style: const TextStyle(color: Colors.white54, fontSize: 12),
          ),
          Text(
            'Recibió Ayuda de ${receivedHelpCount.toString().padLeft(4, '0')} Personas', // ✅ Considera cargar esto del perfil del usuario
            style: const TextStyle(color: Colors.white54, fontSize: 12),
          ),
          const SizedBox(height: 30),

          // SECCIÓN DE CALIFICACIÓN
          // Solo mostrar si el usuario actual NO es el solicitante
          if (currentUser != null && currentUser.uid != requesterUserId) 
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Divider(height: 24, thickness: 1, color: Colors.grey),
                Text(
                  'Calificar a ${requesterName}',
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
                ),
                const SizedBox(height: 16),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(5, (index) {
                    return IconButton(
                      icon: Icon(
                        index < _userRatingForThisRequest ? Icons.star : Icons.star_border,
                        color: Colors.amber,
                        size: 36,
                      ),
                      onPressed: () {
                        setState(() {
                          _userRatingForThisRequest = (index + 1).toDouble();
                        });
                      },
                    );
                  }),
                ),
                Text(
                  'Tu calificación: ${_userRatingForThisRequest.toStringAsFixed(1)} estrellas',
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.white70, fontSize: 14),
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: _ratingCommentController,
                  style: const TextStyle(color: Colors.white, fontSize: 14),
                  decoration: InputDecoration(
                    hintText: 'Añadir un comentario sobre la calificación (opcional)...',
                    hintStyle: TextStyle(color: Colors.white54, fontSize: 14),
                    filled: true,
                    fillColor: Colors.grey[800],
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide.none,
                    ),
                    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  ),
                  maxLines: 3,
                ),
                const SizedBox(height: 16),
                Center(
                  child: ElevatedButton(
                    onPressed: _userRatingForThisRequest > 0 ? () async {
                      try {
                        await FirestoreUtils.saveRating(
                          targetUserId: requesterUserId, 
                          sourceUserId: currentUser!.uid, 
                          rating: _userRatingForThisRequest,
                          requestId: widget.requestId,
                          comment: _ratingCommentController.text.trim(),
                          type: 'helper_rating', // O 'requester_rating' según el contexto
                        );
                        _showSnackBar('Calificación enviada con éxito!', Colors.green);
                        _ratingCommentController.clear();
                        setState(() { _userRatingForThisRequest = 0.0; }); 
                      } catch (e) {
                        _showSnackBar('Error al enviar la calificación: $e', Colors.red);
                      }
                    } : null,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.amber,
                      foregroundColor: Colors.black,
                      padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 12),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(25)),
                    ),
                    child: const Text('Enviar Calificación', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                  ),
                ),
              ],
            ),
          const SizedBox(height: 30),
          Center(
            child: Container(
              width: MediaQuery.of(context).size.width * 0.8,
              height: 50,
              decoration: BoxDecoration(
                color: Colors.grey[900],
                borderRadius: BorderRadius.circular(6),
              ),
              alignment: Alignment.center,
              child: const Text(
                'Ad Banner',
                style: TextStyle(color: Colors.white54, fontSize: 10),
              ),
            ),
          ),
        ],
      ),
    );
  }
}